%% 
%Title: Auditory Machine Intelligence (AMI) Main Code:
%Author: EN Osegi
%Affliation: National Open University of Nigeria (NOUN)
%Date: 23-06-2020
%Version: v1.0

clear all;
clc;

%% DATASETS: 

%% These datasets used in AMI Original Research Paper:
%% Symbolic (Character) Dataset:
load char_set3.mat;% Single-Character Problem
%load char_set33.mat;% Two-Character Problem
                    %Try optimizing Th for this dataset: see that for the
                    %two-character problem, a Th of 0.84 gives perfect fit as
                    %the prediction tails off;
                    %Note Optimization should be typically rounded-off to
                    %two decimal places (dp)
                    %Typical perfect(best) fits is btw 0.84 and 0.93 for
                    %char_set33 dataset

                    

%% Popular time series datasets (see Moritz et al., 2015):
%load air_pass.mat; % trend, seasonality
%load beersales_data.mat; %no trend, seasonality
%load google_data.mat; %no trend, no seasonality
%load SP_data.mat; % trend, no seasonality                    

%% Multivariate:
%load divorce_data.mat;


%% Numenta Anomaly Benchmark Datasets:
%load real_traffic_speed7578_data.mat
%load nyc_taxi.mat;
%load rogue_agent_key_hold.mat;
%load hot_gym_data.mat;

%%
%%



%% Other Datasets For Future Researches:
%% Field Data (Oil Pipeline Pressure Line):
%load pipeline_data.mat;

%% Multivariate:
%load simple_data11a.mat;
%load turkey_power_consumption_2019.mat;
%load france_power_consumption_2014JantJun.mat;
%load data_nn_2times.mat;
%load smart_bed.mat;
%load pipeline_data_lam.mat;
%load dept_store.mat;
%load user_identify_person1.mat;
%load user_identify_person2.mat;
%load dubey_eld_generated_data_chp6.mat;


%% MAIN CODE:

%% Binarization parameter:
Th_ = 0.84; % Typical (Deafault: 0.84).

%% 
sensor_observe = 0;
error_diff_abs_zigma = 0;
cross_entropy = 0;
pred_match = 0;
pred_prob = 0;
error = 0;
win_i = 0;
%%
n = length(input_data_n);
[r,c] = size(input_data_n);


%% Continual Data-Entry:
for i = 1:n
    sensor(i,:) = input_data_n(i,:);
    
    if(c>1)
        [data_in_orig] = binarization(sensor,Th_);
        [data_numeric] = numeric_to_str_to_numeric_concatenator_func(data_in_orig);
    else
        data_numeric = sensor;
    end
            
    if(i>=2)
      %c = 1;   
        
        [pred_out,winners_idx] = ...
            AMI_phase1(data_numeric);
        
                
        if(c>1)
            
            winners_predict(i,:) = sensor(winners_idx,:);
            pred_out = winners_predict;
            
        end
%% MAPE Model (As computed in Cui et al (2016):        
        error = error + abs((sensor(i,c)-pred_out(i,c))); %MAPE Error Sum
        sensor_observe = sensor_observe + abs(sensor(i,c));
        error_n(i,:) = error/sensor_observe;
        pred_actual(i,:) = [pred_out(i,c),sensor(i,c)];
        error_mean = mean(error_n);
        
        
%% Cross-entropy loss:     
        
    [cross_entropy(i,:)] = loss_ce(sensor, pred_out,i);
    %cross_entropy = filter_cross_entropy(cross_entropy_i);
       
    end
    

    i_count = i
        
end


%% Cross-entropy Score:
mean(cross_entropy)


%%
%Copyright: (c) EN Osegi, Dept. of Inf.Tech  National Open University of Nigeria(NOUN)




