%% 
%Title: AMI auxilliary functional class: cross-entropy loss
%Author: EN Osegi
%Affliation: National Open University of Nigeria (NOUN)
%Date: 23-06-2020
%Version: v1.0

function [cross_entropy] = loss_ce(data_actual, data_pred,n)

%Note: Cross entropy requires a scaled input between 0 and 1.

cross_entropy = 0;
uo_error_diff = 0;
pred_match = 0;
min_bias = 0.1;

error_diff_abs = abs(data_pred-data_actual);
uo_error_diff = (uo_error_diff+error_diff_abs)/n;

    if(error_diff_abs > uo_error_diff)
        pred_match = pred_match + 1; %
    end
pred_prob=((pred_match)/n)+min_bias;

cross_entropy = cross_entropy + (pred_prob*(-log2(pred_prob))/n);

end