%% 
%Title: AMI functional class (Phase-1)with learning
%Author: EN Osegi
%Affliation: National Open University of Nigeria (NOUN)
%Date: 23-06-2020
%Version: v1.0

function [prediction,winners_idx] = ...
    AMI_phase1_learn(Th,s,monte_carlo_trials,sensor)

n = length(sensor);

lp = 0.01;
dev_mean_1 = 0.0;
kp_rand = 0.0;
Th_update = Th;


S_dev_k = 0;
winners_idx = [];
forecast_horizon = 12;
back_step = 1; 
%% 

for k = 1:monte_carlo_trials   

%% Sparsity Rule Formation: 
so = roundn((s*n)/100,0);

Th_update_n = Th_update;

     if(so == 0)
        
        so = 1;
        kp_rand = 1.0;
        
    else
        
        for kk =1:so
               
          kp = rand; 
          kp_rand = kp_rand + rand;
           
        end    
              
            if(kp_rand > Th_update)
                
              kp_rand = 1.0;
                   
            else
                
              kp_rand = 0.0;
              
            end
            
      end  


%% Sparsity Rule Formation End               
   

%% AMI-PHASE 1 STARTS HERE:

        for i = 2:n
             
             S_stand_a(i-1,:) = sensor(i-1,:)*kp_rand; 
             S_n_minus_1_a = sensor(i);

        end

        for i = 2:n

         S_dev_a(i-1,:) = (S_n_minus_1_a-S_stand_a(i-1,:)); %Normal deviatio
         S_dev_k  = S_dev_k+(S_n_minus_1_a-S_stand_a(i-1,:));
         S_dev_abs = abs(S_dev_a);%Absolute deviation
         dev_mean_1 = (((S_dev_k/(n-1))+S_n_minus_1_a)-2)/...
                                    (n+1);
        
%% Model Adjustment:
        prob_ = 1-(S_dev_abs/S_dev_k);
        if(prob_ >= 0.8)

            k_sel = i;

            winners_idx = [k_sel];
            
        else
            
            winners_idx = 1;
            
        end  
        
        prediction(i,:) = ((dev_mean_1) + sensor(i-1,:));  

        S_diff = prediction(i,:) - sensor(i,:);

        end
        
               if(S_diff>0)
                 dev_mean_1 = dev_mean_1 - abs(S_diff);
                 Th_update =  min(Th_update+0.01,1);                   

               elseif(S_diff<0)
                  dev_mean_1 = dev_mean_1 + abs(S_diff);
                  %Th_update =  max(Th_update-0.01,0);                                     

               else
                  dev_mean_1 = dev_mean_1 + lp;
                  Th_update = Th_update+lp; 
               end  
            
    [predictions] = AMI_phase2(prediction,...
    mean(dev_mean_1),forecast_horizon,back_step);
end
%%  Learning starts here:



           
%% // Learning ends               
      


end









