%% 
%Title: Auditory Machine Intelligence (AMI) Main Code (Smart Classroom):
%Author: EN Osegi
%Affliation: National Open University of Nigeria (NOUN)
%Date: 23-06-2020
%Version: v1.0

clear all;
clc;

%% Smart-Classroom Data:
load smart_class_room_data10pts.mat;
%load smart_class_room_data50pts.mat;
%load smart_class_room_data100pts.mat;
%load smart_class_room_data1000pts.mat;

%% MAIN CODE:
%% Binarization parameter:
Th_ = 0.84; % Typical (Deafault: 0.84).

%% 
sensor_observe = 0;
error_diff_abs_zigma = 0;
cross_entropy = 0;
pred_match = 0;
pred_prob = 0;
error = 0;
win_i = 0;
%%
n = length(input_data_n);
[r,c] = size(input_data_n);



%% Continual Data-Entry:
for i = 1:n
    sensor(i,:) = input_data_n(i,:);
    
    if(c>1)
        [data_in_orig] = binarization(sensor,Th_);
        [data_numeric] = numeric_to_str_to_numeric_concatenator_func(data_in_orig);
    else
        data_numeric = sensor;
    end
            
    if(i>=2)
      %c = 1;   
        
        [pred_out,winners_idx] = ...
            AMI_phase1(data_numeric);
        
                
        if(c>1)
            
            winners_predict(i,:) = sensor(winners_idx,:);
            pred_out = winners_predict;
            
        end
%% MAPE Model (As computed in Cui et al (2016):        
        error = error + abs((sensor(i,c)-pred_out(i,c))); %MAPE Error Sum
        sensor_observe = sensor_observe + abs(sensor(i,c));
        error_n(i,:) = error/sensor_observe;
        pred_actual(i,:) = [pred_out(i,c),sensor(i,c)];
        error_mean = mean(error_n);
        
        
%% Cross-entropy loss:     
        
    [cross_entropy(i,:)] = loss_ce(sensor, pred_out,i);
    %cross_entropy = filter_cross_entropy(cross_entropy_i);
       
    end
    

    i_count = i
        
end


%% Temp Control Signals:
control_states = pred_actual>27; %CT = 27 degC
CA = 100*sum(control_states(:,1)==control_states(:,2))/n;

%% Cross-entropy Score:
mean(cross_entropy)


%%
%Copyright: (c) EN Osegi, Dept. of Inf.Tech  National Open University of Nigeria(NOUN)




