%% 
%Title: AMI auxilliary functional class: number-to-string-to-number concatenator
%Author: EN Osegi
%Affliation: National Open University of Nigeria (NOUN)
%Date: 23-06-2020
%Version: v1.0

function [numeric_val] = numeric_to_str_to_numeric_concatenator_func(data_in)


        gg = num2str(data_in);
        [ro,co] = size(gg);
        
    if(co == 1)
        numeric_val = data_in;
        
    else
        len_data_in = co;

        hh = 1;
        for ii = 1:len_data_in
            if(ii<=len_data_in && hh <len_data_in)
                hh = hh + 3;
                hz(ii) = hh;
            end
        end

        hz = [1 hz];
        gg_new = gg(:,hz);
        numeric_val = str2num(gg_new);
        
    end
        
end
    
