%% 
%Title: AMI auxilliary functional class: Binary Encoder
%Author: EN Osegi
%Affliation: National Open University of Nigeria (NOUN)
%Date: 23-06-2020
%Version: v1.0

function [binarization_out_n] = binarization(data_in,Th)
    
    in_max = max(max(data_in));
    [ro,co] = size(data_in);
    
    for i = 1:ro
        
       binarization_out(i,:) = data_in(i,:)./in_max;
        
    end
       
       %% Change-Detection:
       binarization_out_n = ((binarization_out)>Th).*1;
end