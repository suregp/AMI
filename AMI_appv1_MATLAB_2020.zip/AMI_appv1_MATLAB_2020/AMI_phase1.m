%% 
%Title: AMI functional class (Phase-1)
%Author: EN Osegi
%Affliation: National Open University of Nigeria (NOUN)
%Date: 23-06-2020
%Version: v1.0

function [prediction,winners_idx] = ...
    AMI_phase1(sensor)

n = length(sensor);
%[n,c] = size(sensor);

S_dev_k = 0;
winners_idx = [];

forecast_horizon = 12;
back_step = 1; 
%% AMI-PHASE 1 STARTS HERE:    
    for i = 2:n

     S_stand_a(i-1,:) = sensor(i-1,:);  
     S_n_minus_1 = sensor(i);
     
    end

    for i = 2:n

     S_dev_a(i-1,:) = (S_n_minus_1-S_stand_a(i-1,:)); %Normal deviatio
     S_dev_k  = S_dev_k+abs(S_n_minus_1-S_stand_a(i-1,:));
     S_dev_abs = abs(S_dev_a);%Absolute deviation
     dev_mean_1 = (((S_dev_k/(n-1))+S_n_minus_1)-2)/...
                                (n+1);
    
%% Model Adjustment:
        prob_ = 1-(S_dev_abs/S_dev_k);
        if(prob_ >= 0.8)

            k_sel = i;

            winners_idx = [k_sel];
            
        else
            
            winners_idx = 1;
            
        end
                                                         
    prediction(i,:) = ((dev_mean_1) + sensor(i-1,:));    
    

    end
    
    
    [predictions] = AMI_phase2(prediction,...
    mean(dev_mean_1),forecast_horizon,back_step);

end









