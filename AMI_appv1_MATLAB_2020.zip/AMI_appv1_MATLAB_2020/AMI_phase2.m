%% 
%Title: AMI functional class (Phase-2)
%Author: EN Osegi
%Affliation: National Open University of Nigeria (NOUN)
%Date: 23-06-2020
%Version: v1.0


function [predictions] = AMI_phase2(iForecast_o_n_best,...
    avg_dev_mean,forecast_horizon,back_step)



n_el_in_x = numel(iForecast_o_n_best);
nth_data_in = iForecast_o_n_best(n_el_in_x);
nth_data_in_minus1 = iForecast_o_n_best(n_el_in_x-1);
fout = zeros(forecast_horizon,1);
fout_first = iForecast_o_n_best(1);
fout_last = iForecast_o_n_best(n_el_in_x-back_step);
fout(1) = fout_last;


%% Compute the State Change Matrix (SCM) of training forecasts 
%% via conditional encoding:
kout = zeros(forecast_horizon,1);

%Determine initial State encoding:
    %if(fout(2) > fout(1))
        %kout(1) = 3; 
    %elseif(fout(2) == fout(1))
       % kout(1) = 2; 
    %elseif(fout(2) < fout(1))
        %kout(1) = 1; 
    %end

%% Change detection and Encoding:    
%Compute State Change Encoding:    
for j = 2:numel(iForecast_o_n_best)
    if(iForecast_o_n_best(j)>iForecast_o_n_best(j-1))
        kout(j-1,:) = 3;
    elseif(iForecast_o_n_best(j)==iForecast_o_n_best(j-1))
        kout(j-1,:) = 2;
        elseif(iForecast_o_n_best(j)<iForecast_o_n_best(j-1))
        kout(j-1,:) = 1;
    end
end

%kout = nonzeros(kout);
state_transitions = kout;% State Change Transition Matrix (SCM)

%% Use the SCM for Multi-step ahead Forecasts:
for i = 2:forecast_horizon
    if(kout(i-1)==3)
        fout(i,:) = fout(i-1) + avg_dev_mean;
    elseif(kout(i-1)==2)
        fout(i,:) = fout(i-1);
    elseif(kout(i-1)==1)
        fout(i,:) = fout(i-1) - avg_dev_mean;
    end
end
    




predictions = fout;

end
        


